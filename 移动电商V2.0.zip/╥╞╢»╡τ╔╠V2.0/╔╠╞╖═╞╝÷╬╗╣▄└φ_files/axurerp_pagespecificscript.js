for(var i = 0; i < 97; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u77'] = 'center';
$axure.eventManager.focus('u38', function(e) {

if (true) {

SetWidgetFormText('u38', '');

}
});

$axure.eventManager.blur('u38', function(e) {

if (true) {

SetWidgetFormText('u38', '请输入商品名称');

}
});
gv_vAlignTable['u32'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u89'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('订单管理.html');

}
});
gv_vAlignTable['u17'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u71'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'top';
$axure.eventManager.focus('u92', function(e) {

if (true) {

SetWidgetFormText('u92', '');

}
});

$axure.eventManager.blur('u92', function(e) {

if (true) {

SetWidgetFormText('u92', '请填写推荐位名称');

}
});
gv_vAlignTable['u83'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺推荐位管理.html');

}
});
gv_vAlignTable['u22'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品管理.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	SetPanelVisibility('u59','','none',500);

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u73'] = 'center';document.getElementById('u84_img').tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});
u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u28'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u12'] = 'top';u42.tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	SetPanelVisibility('u59','','none',500);

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u63'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u80'] = 'top';