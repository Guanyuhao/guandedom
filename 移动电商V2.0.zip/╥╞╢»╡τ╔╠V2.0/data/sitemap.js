﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m,i,[_(c,n,e,f,g,o),_(c,p,e,f,g,q),_(c,r,e,f,g,s)]),_(c,t,e,f,g,u,i,[_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C,i,[_(c,D,e,f,g,E),_(c,F,e,f,g,G)]),_(c,H,e,f,g,I),_(c,J,e,f,g,K),_(c,L,e,f,g,M,i,[_(c,N,e,f,g,O)]),_(c,P,e,f,g,Q),_(c,R,e,f,g,S),_(c,T,e,f,g,U),_(c,V,e,f,g,W,i,[_(c,X,e,f,g,Y)])])])]);}; 
var b="rootNodes",c="pageName",d="主页",e="type",f="Wireframe",g="url",h="主页.html",i="children",j="移动电商V2.0需求汇总表",k="移动电商V2_0需求汇总表.html",l="我的账户",m="我的账户.html",n="账户概览",o="账户概览.html",p="个人资料",q="个人资料.html",r="商铺资料",s="商铺资料.html",t="我是卖家",u="我是卖家.html",v="发布新商品",w="发布新商品.html",x="商品管理",y="商品管理.html",z="店铺广告",A="店铺广告.html",B="订单管理",C="订单管理.html",D="查看订单",E="查看订单.html",F="待发货",G="待发货.html",H="支付方式管理",I="支付方式管理.html",J="配送方式管理",K="配送方式管理.html",L="商品分类管理",M="商品分类管理.html",N="商品排序",O="商品排序.html",P="店铺推荐位管理",Q="店铺推荐位管理.html",R="商品推荐位管理",S="商品推荐位管理.html",T="退换货说明",U="退换货说明.html",V="店铺统计",W="店铺统计.html",X="统计详情",Y="统计详情.html";
return _creator();
})();
