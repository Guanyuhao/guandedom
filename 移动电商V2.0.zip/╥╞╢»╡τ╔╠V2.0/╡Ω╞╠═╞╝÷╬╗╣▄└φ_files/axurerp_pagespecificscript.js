for(var i = 0; i < 112; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';document.getElementById('u55_img').tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelVisibility('u69','','none',500);

}
});
gv_vAlignTable['u46'] = 'top';
u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	SetPanelVisibility('u69','hidden','none',500);

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u32'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品推荐位管理.html');

}
});
gv_vAlignTable['u23'] = 'top';u62.tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	SetPanelVisibility('u69','','none',500);

}
});
gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';u60.tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u69','','none',500);

}
});
gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u89'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('订单管理.html');

}
});
gv_vAlignTable['u17'] = 'top';u64.tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	SetPanelVisibility('u83','','none',500);

}
});
gv_vAlignTable['u64'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'top';document.getElementById('u108_img').tabIndex = 0;

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	SetPanelVisibility('u83','hidden','none',500);

}
});
gv_vAlignTable['u71'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'center';u58.tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	SetPanelVisibility('u69','','none',500);

}
});
gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u95'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u22'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品管理.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u73'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u28'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';u65.tabIndex = 0;

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	SetPanelVisibility('u83','','none',500);

}
});
gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'top';u63.tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	SetPanelVisibility('u83','','none',500);

}
});
gv_vAlignTable['u63'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u59'] = 'top';