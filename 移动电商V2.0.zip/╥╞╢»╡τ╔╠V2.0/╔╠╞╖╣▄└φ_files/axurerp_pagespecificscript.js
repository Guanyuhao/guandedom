for(var i = 0; i < 85; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u46'] = 'center';document.getElementById('u77_img').tabIndex = 0;

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	SetPanelVisibility('u74','hidden','none',500);

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品推荐位管理.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('订单管理.html');

}
});
gv_vAlignTable['u17'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u71'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	SetPanelVisibility('u52','','none',500);

}
});
gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u83'] = 'center';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺推荐位管理.html');

}
});
gv_vAlignTable['u22'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';u68.tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	SetPanelVisibility('u74','','none',500);

}
});
gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u84'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'top';
u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u56'] = 'center';document.getElementById('u82_img').tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';
$axure.eventManager.focus('u48', function(e) {

if (true) {

SetWidgetFormText('u48', '');

}
});

$axure.eventManager.blur('u48', function(e) {

if (true) {

SetWidgetFormText('u48', '请输入商品名称');

}
});
gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u80'] = 'top';