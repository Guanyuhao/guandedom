for(var i = 0; i < 187; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u140'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('订单管理.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u179'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u128'] = 'top';u182.tabIndex = 0;

u182.style.cursor = 'pointer';
$axure.eventManager.click('u182', function(e) {

if (true) {

	SetPanelVisibility('u175','hidden','fade',500);

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u114'] = 'top';document.getElementById('u160_img').tabIndex = 0;

u160.style.cursor = 'pointer';
$axure.eventManager.click('u160', function(e) {

if (true) {

	SetPanelVisibility('u162','','none',500);

}
});
gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u126'] = 'top';u181.tabIndex = 0;

u181.style.cursor = 'pointer';
$axure.eventManager.click('u181', function(e) {

if (true) {

SetWidgetFormText('u172', '');

}
});
gv_vAlignTable['u98'] = 'top';u169.tabIndex = 0;

u169.style.cursor = 'pointer';
$axure.eventManager.click('u169', function(e) {

if (true) {

	SetPanelVisibility('u162','hidden','fade',500);

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';u168.tabIndex = 0;

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if (true) {

SetWidgetFormText('u159', '');

}
});
gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u104'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';u170.tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

SetWidgetFormText('u159', '' + (GetGlobalVariableValue('Year')) + '-' + (GetGlobalVariableValue('Month')) + '-' + (GetGlobalVariableValue('Day')) + '');

	SetPanelVisibility('u162','hidden','fade',500);

}
});
gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u177'] = 'center';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u70'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品推荐位管理.html');

}
});
gv_vAlignTable['u23'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品管理.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u58'] = 'top';u183.tabIndex = 0;

u183.style.cursor = 'pointer';
$axure.eventManager.click('u183', function(e) {

if (true) {

SetWidgetFormText('u172', '' + (GetGlobalVariableValue('Year')) + '-' + (GetGlobalVariableValue('Month')) + '-' + (GetGlobalVariableValue('Day')) + '');

	SetPanelVisibility('u175','hidden','fade',500);

}
});
document.getElementById('u173_img').tabIndex = 0;

u173.style.cursor = 'pointer';
$axure.eventManager.click('u173', function(e) {

if (true) {

	SetPanelVisibility('u175','','none',500);

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u146'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u148'] = 'top';u167.tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

SetWidgetFormText('u159', '2011-8-24');

	SetPanelVisibility('u162','hidden','fade',500);

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u90'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u161'] = 'center';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺推荐位管理.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u136'] = 'top';u180.tabIndex = 0;

u180.style.cursor = 'pointer';
$axure.eventManager.click('u180', function(e) {

if (true) {

SetWidgetFormText('u172', '2011-8-24');

	SetPanelVisibility('u175','hidden','fade',500);

}
});
gv_vAlignTable['u28'] = 'center';