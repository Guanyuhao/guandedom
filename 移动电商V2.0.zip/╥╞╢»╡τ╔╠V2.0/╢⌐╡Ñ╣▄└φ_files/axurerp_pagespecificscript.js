for(var i = 0; i < 111; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u102'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u77'] = 'top';
u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

	SetPanelVisibility('u84','hidden','none',500);

	SetPanelVisibility('u100','','none',500);

}
});
gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u38'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品推荐位管理.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u17'] = 'top';
u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	SetPanelVisibility('u84','','none',500);

}
});
u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u71'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u95'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺推荐位管理.html');

}
});
gv_vAlignTable['u22'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品管理.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u90'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u28'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u6'] = 'center';
$axure.eventManager.focus('u96', function(e) {

if (true) {

SetWidgetFormText('u96', '');

}
});

$axure.eventManager.blur('u96', function(e) {

if (true) {

SetWidgetFormText('u96', '请输入单号。。。');

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u91'] = 'top';document.getElementById('u35_img').tabIndex = 0;

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('待发货.html');

}
});
gv_vAlignTable['u26'] = 'top';
u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('查看订单.html');

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';
u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('查看订单.html');

}
});
gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u80'] = 'top';