for(var i = 0; i < 80; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺统计.html');

}
});
gv_vAlignTable['u21'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('退换货说明.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';
u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	SetPanelVisibility('u50','hidden','none',500);

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u32'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品推荐位管理.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u34'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('订单管理.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('配送方式管理.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u71'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺广告.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u37'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('店铺推荐位管理.html');

}
});
gv_vAlignTable['u22'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品管理.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u73'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('商品分类管理.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u28'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('发布新商品.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';document.getElementById('u56_img').tabIndex = 0;

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	SetPanelVisibility('u58','','none',500);

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u33'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付方式管理.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';
u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	SetPanelVisibility('u58','','none',500);

}
});

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	SetPanelVisibility('u50','','none',500);

	SetPanelVisibility('u58','hidden','none',500);

}
});
