$(function () {
	
	function lb (id) {
		this.index = 0;
		this.figure = $("#"+id);
		this.lunbo = this.figure.find('.lunbo');
		this.order = this.figure.find('.order');
		
		this.lunboli = this.lunbo.children();
		this.orderli = this.order.children();
		
		this.prevbtn = this.figure.find('.prev-btn');
		this.nextbtn = this.figure.find('.next-btn');
		
		this.length = this.lunboli.length;
		
		this.start();
		this.thing();
	}
	lb.prototype.start = function  () {
		var _this = this;
		this.timer = setInterval(function () {
			_this.move();
		},2000)
	}
	lb.prototype.move = function  () {
		
		if (this.index == this.length-1) {
			this.index = 0;
		}else{
			this.index++;
		}
		this.lunboli.eq(this.index).fadeIn().siblings().fadeOut();
		this.orderli.eq(this.index).addClass("red").siblings().removeClass('red');
	}
	
	lb.prototype.thing = function(){
		var _this = this;
		this.orderli.on({
			"mouseenter":function () {
				_this.clear();
			},
			"mouseleave":function () {
				_this.start();
			},
			"click":function  () {
				
				_this.index = $(this).index()-1;
				_this.move();
			}
		});
		this.prevbtn.on({
			"mouseenter":function () {
				
				$(this).addClass("black");
			},
			"mouseleave":function () {
				
				$(this).removeClass("black");
			},
			"click":function () {
				_this.clear();
				//防止点击的定时器运行而导致少跑一张或者多跑一张
				if (_this.index == 0 ) {
					_this.index = _this.length;
				}
				_this.lunboli.eq(_this.index-1).fadeIn().siblings().fadeOut();
				_this.orderli.eq(_this.index-1).addClass("red").siblings().removeClass('red');
				
				//点击的时候更好图片不影响定时器   修改完成后需要重新给index 赋值保证定时器正常 以及下次的点击
				
				_this.index = _this.index-1;
				//完成搞鬼之后重启定时器
				_this.start();
			}
		});
		this.nextbtn.on({
			"mouseenter":function () {
				
				$(this).addClass("black");
			},
			"mouseleave":function () {
				
				$(this).removeClass("black");
			},
			"click":function () {
				_this.clear();
				if (_this.index == _this.length-1) {
					_this.index = -1;
				}
				_this.lunboli.eq(_this.index+1).fadeIn().siblings().fadeOut();
				_this.orderli.eq(_this.index+1).addClass("red").siblings().removeClass('red');
				_this.index = _this.index+1;
				_this.start();
			}
		});
		
	}
	lb.prototype.clear = function () {
		clearInterval(this.timer)
	}
	
	new lb("Carousel-figure")
	
	//封装成对象后 以后再需要这种特性直接调用
})
